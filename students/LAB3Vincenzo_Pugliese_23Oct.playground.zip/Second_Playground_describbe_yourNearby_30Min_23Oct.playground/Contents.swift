//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


let name, surname : String
let age : Int

let corso : String

var titoloStudio : String

let citta: String


var hobby : String
var degree : Bool

var nationality: String


name = "Giovanni"
surname = "Di Iorio"

age = 22
titoloStudio = "Liceo Classico"
corso = "standard"
citta = "Taurasi /AV"
hobby = "Chitarra Elettrica, game design, cinema"

nationality = "Italian"

print (name);
print (surname);
print ("ANNI \(age)");



print ("GIOVANNI tiene il titolo di studio: " + (titoloStudio) + "")
print ("GIOVANNI FREQUENTA LA " + " " + (corso) + " class")
print ("GIOVANNI e' di  " + (citta) + "")
print ("GIOVANNI ha questi hobby:   \(hobby)")

degree =  false //var booleana inizializata


if degree == false {                            //controllo condizionale IF
    print("Giovanni non è ancora laureato")
}
else if degree==true {
    print("Giovanni si è finalmente laureato")
}


if corso == "standard" {                            //controllo condizionale IF
    print("Giovanni frequenta la Standard class")
}
else if corso=="master" {
    print("Giovanni frequenta la master class")
}


for day in 1...5 {
    print("Day\(day) - non ti scordare di  badgiare !")
    
                }

////SEpaeratore// dati di Sara alla mia sinistra

//: Playground - noun: a place where people can play






let name2, surname2 : String
let age2 : Int

let corso2 : String

var titoloStudio2 : String

let citta2: String


var hobby2 : String
var degree2 : Bool

var  nationality2 : String


name2 = "Sara"
surname2 = "Brancato"

age2 = 23
titoloStudio2 = "Ingegneria Biomedica"
corso2 = "standard"
citta2 = "Caserta CE"
hobby2 = "gatti,teatro, cinema"
nationality2 = "Italian"

print (name2);
print (surname2);
print ("ANNI \(age2)");



print ("SARA tiene il titolo di studio: " + (titoloStudio2) + "")
print ("SARA FREQUENTA LA " + " " + (corso2) + " class")
print ("SARA e' di  " + (citta2) + "")
print ("SARA ha questi hobby:   \(hobby)")

degree2 =  true //var booleana inizializata


if degree2 == false {                            //controllo condizionale IF
    print("SARA non è ancora laureatA")
}
else if degree2==true {
    print("SARA si è finalmente laureata")
}


if corso2 == "standard" {                            //controllo condizionale IF
    print("SARA frequenta la Standard class")
}
else if corso2=="master" {
    print("SARA frequenta la master class")
}


for day in 1...5 {
    print("Day\(day) - non ti scordare di  badgiare !")
    
}



if (nationality && nationality2) == "Italian" {
    
    print("i due compagni di banco sono entrambi italiani, ci offrissero un piatto di pasta e un caffe espresso!")
                                         }





