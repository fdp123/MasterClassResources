/************************************************************************/
/*                                                                      */
/* Ceaser Cipher Brute Force Decryption in Swift (by Claudio Elefante)  */
/*                                                                      */
/************************************************************************/

let alphabet: [Character] = Array("abcdefghijklmnopqrstuvwxyz")

/* Insert here the cipher text */
let cipher_text: String = "AbCdE"

let ciphered_chars_array: [Character] = Array(cipher_text.lowercased())
var decrypted_chars_array = [Character]()

// for each key value
for i in (1...26)
{
    // for each cyphred char
    for j in (0...(ciphered_chars_array.count - 1))
    {
        decrypted_chars_array.insert(alphabet[((alphabet.index(of: ciphered_chars_array[j])! - i + 26) % 26)], at: j)
    }
    print("Key: \(i), Plaintext: \(String(decrypted_chars_array))")
    decrypted_chars_array.removeAll()
}
